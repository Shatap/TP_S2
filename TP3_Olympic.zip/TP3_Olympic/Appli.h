#ifndef APPLI_H
#define APPLI_H

#include <SFML/Graphics.hpp>

class Appli
{
public:
    Appli();
    void run();

private:
    sf::RenderWindow m_window;
    bool             m_appli_running;
    
    sf::Vector2f m_mouse;          // position de la souris
    sf::Mouse::Button m_button;    // numéro bouton appuyé/relâché
    
    void process_events();

    // fonctions à compléter
    
    void draw();

    void keyPressed(sf::Keyboard::Key code);
    void mousePressed();
    void mouseReleased();
    void mouseMoved();
};

#endif // APPLI_H
