#ifndef SALLE_H
#define SALLE_H

class Salle
{
private:
    m_voisins
public:
    Salle();
};

#endif // SALLE_H
