#ifndef PERSONNAGE_H
#define PERSONNAGE_H

#include <string>

class Personnage
{
public:
    Personnage(std::string &nom,
    std::string &description);
};

#endif // PERSONNAGE_H
