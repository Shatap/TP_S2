#include "Objet.h"

Objet::Objet()
{
}
