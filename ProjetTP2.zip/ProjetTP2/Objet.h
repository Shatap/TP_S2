#ifndef OBJET_H
#define OBJET_H

class Objet
{
public:
    Objet();
};

#endif // OBJET_H
