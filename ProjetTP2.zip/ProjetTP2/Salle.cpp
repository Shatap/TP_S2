#include "Salle.h"

Salle::Salle()
{
}
