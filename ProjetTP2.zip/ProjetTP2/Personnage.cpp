#include "Personnage.h"

Personnage::Personnage(std::string &nom,
                       std::string &description)
{
}
